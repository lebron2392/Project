CREATE VIEW stock_store AS
  SELECT
    `mrp`.`stock`.`part_code`  AS `part_code`,
    `mrp`.`stock`.`store_code` AS `store_code`,
    `mrp`.`stock`.`quantity`   AS `quantity`,
    `mrp`.`store`.`name`       AS `name`
  FROM (`mrp`.`stock`
    JOIN `mrp`.`store`)
  WHERE (`mrp`.`store`.`store_code` = `mrp`.`stock`.`store_code`);
